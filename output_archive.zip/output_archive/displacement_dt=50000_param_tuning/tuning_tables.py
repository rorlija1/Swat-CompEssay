#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  1 10:08:32 2025

@author: rowan
"""

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

MP_layers = [7, 
             6, 
             12, #4
             18, 
             3, #6
             3, 
             3, 
             6, #10
             6, 
             6, #12
             7, 
             12, #14
             12, 
             18, #16
             18,
             18, #18
             7,
             7]
edge_threshold = [3, 
                  3, 
                  3, #4
                  3, 
                  3, #6
                  6, 
                  18,
                  6, #10
                  12, 
                  18, #12
                  6,
                  6, #14
                  12,
                  18, #16
                  12,
                  6, #18
                  12,
                  18]
learning_rate = [1e-4, 1e-4, 1e-4, 1e-4, 1e-4, 1e-4, 1e-4, 
                 1e-4, 1e-4, 1e-4, 1e-4, 1e-4, 1e-4, 1e-4, 1e-4,
                 1e-4, 1e-4, 1e-4]
best_RMSE = [(0.03666871413588524 + 0.03129949793219566) / 2, #1
             (0.035438649356365204 + 0.04019355773925781) / 2, #3
             (0.028279069811105728 + 0.027327843010425568) / 2, 
             0.025457359850406647, #5
             (0.15023097395896912 + 0.15836183726787567) / 2,
             (0.033825941383838654 + 0.05038128420710564) / 2, #7
             0.027702243998646736, #9
             (0.05591978877782822 + 0.02615831233561039) / 2, 
             0.021465113386511803, #11
             0.018930189311504364, 
             (0.04075648635625839 + 0.023908207193017006) / 2, #13
             (0.040882378816604614 + 0.025978272780776024) / 2, 
             (0.02019858919084072 + 0.029719118028879166) / 2, #15
             0.6177279949188232, 
             0.01787809282541275, #17
             0.020300032570958138,
             0.029127396643161774, #19
             (0.0199936181306839 + 0.023074351251125336) / 2] #
best_epoch = [(395 + 457) / 2, #1
              (253 + 630) / 2, #3
              (355 + 478) / 2, 
              (320 + 42) / 2, #5
              (1000 + 2252) / 2, 
              (582 + 552) / 2, #7
              377, #9
              (387 + 219) / 2, 
              238, #11
              148,
              (243 + 281) / 3, #13
              (633 + 234) / 2, 
              (159 + 152) / 2, #15
              94, 
              237, #17
              182,
              217, #19
              (171 + 142) / 2]

best_RMSE_100plus = [(0.03666871413588524 + 0.03129949793219566) / 2, #1,
             (0.035438649356365204 + 0.04019355773925781) / 2, #3
             (0.028279069811105728 + 0.027327843010425568) / 2, 
             0.025457359850406647, #5
             (0.033825941383838654 + 0.05038128420710564) / 2, #7
             0.027702243998646736, #9
             (0.05591978877782822 + 0.02615831233561039) / 2, 
             0.021465113386511803, #11
             0.018930189311504364, 
             (0.04075648635625839 + 0.023908207193017006) / 2, #13
             (0.040882378816604614 + 0.025978272780776024) / 2, 
             (0.02019858919084072 + 0.029719118028879166) / 2, #15
             0.01787809282541275, #17
             0.020300032570958138,
             0.029127396643161774, #19
             (0.0199936181306839 + 0.023074351251125336) / 2] #
best_epoch_100plus = [(395 + 457) / 2, #1
              (253 + 630) / 2, #3
              (355 + 478) / 2, 
              320, #5
              (582 + 552) / 2, #7
              377, #9
              (387 + 219) / 2, 
              238, #11
              148,
              (243 + 281) / 3, #13
              (633 + 234) / 2, 
              (159 + 152) / 2, #15
              237, #17
              182,
              217, #19
              (171 + 142) / 2]

MP_layers_100plus = [7, 
             6, 
             12, #4
             18, 
             3, 
             3, 
             6, #10
             6, 
             6, #12
             7, 
             12, #14
             12, 
             18,
             18, #18
             7,
             7]
edge_threshold_100plus = [3, 
                  3, 
                  3, #4
                  3, 
                  6, 
                  18,
                  6, #10
                  12, 
                  18, #12
                  6,
                  6, #14
                  12,
                  12,
                  6, #18
                  12,
                  18]
learning_rate_100plus = [1e-4, 1e-4, 1e-4, 1e-4, 1e-4, 1e-4, 
                 1e-4, 1e-4, 1e-4, 1e-4, 1e-4, 1e-4, 1e-4, 1e-4,
                 1e-4, 1e-4]

early_stop_100plus = [True, True, True, 
              True, True, True, True, True, True, 
              True, True, True, True, True, True,
              True]

early_stop = [True, True, True, True, False, 
              True, True, True, True, True, True, 
              True, True, True, True, True,
              True, True]

df = pd.DataFrame({
    "MP_layers": MP_layers, 
    "edge_threshold": edge_threshold, 
    "learning_rate": learning_rate, 
    "best_RMSE": best_RMSE,
    "best_epoch": best_epoch,
    "early_stop": early_stop
})

df_100plus =  pd.DataFrame({
    "MP_layers": MP_layers_100plus, 
    "edge_threshold": edge_threshold_100plus, 
    "learning_rate": learning_rate_100plus, 
    "best_RMSE": best_RMSE_100plus,
    "best_epoch": best_epoch_100plus,
    "early_stop": early_stop_100plus
})

def table(df, output_path="tuning_table.png"):

    # Format
    df_sorted = df.copy()
    df_sorted = df_sorted.sort_values(by="best_RMSE", ascending=True)
    df_sorted["learning_rate"] = df_sorted["learning_rate"].map(lambda x: f"{x:.3e}")
    df_sorted["best_RMSE"] = df_sorted["best_RMSE"].map(lambda x: f"{x:.3e}")


    #figure size 
    fig, ax = plt.subplots(figsize=(12, 2 + 0.3 * len(df_sorted)))
    ax.axis('off')

    table = ax.table(
        cellText=df_sorted.values,
        colLabels=df_sorted.columns,
        cellLoc='center',
        loc='center'
    )

    table.scale(1.2, 1.4)
    table.auto_set_font_size(False)
    table.set_fontsize(10)

    header_color = '#cfe2f3'  # light blue
    for (row, col), cell in table.get_celld().items():
        if row == 0:
            cell.set_text_props(weight='bold', color='black')
            cell.set_facecolor(header_color)

    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    print(f"Saved tuning table to {output_path}")

def heatmap(df, learning_rate_value, output_path="MPLvsedge_heatmap.png"):
    """
    Filters data for a specific learning rate and plots best_RMSE as a heatmap
    with edge_threshold as rows and MP_layers as columns.
    """
    filtered_df = df[df["learning_rate"] == learning_rate_value]
    if filtered_df.empty:
        print(f"No data found for learning rate {learning_rate_value}")
        return

    heatmap_df = filtered_df.pivot_table(
        index="edge_threshold",
        columns="MP_layers",
        values="best_RMSE"
    )

    # Plot
    plt.figure(figsize=(8, 6))
    sns.heatmap(heatmap_df, annot=True, fmt=".4f", cmap="coolwarm", cbar=True,
                linewidths=0.5, linecolor='gray')
    plt.title(f"Best RMSE (Validation) for Learning Rate = {learning_rate_value}", fontsize=14)
    plt.xlabel("MP Layers")
    plt.ylabel("Edge Threshold")
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    print(f"Saved heatmap to {output_path}")

table(df)
heatmap(df, learning_rate_value=1e-4)
heatmap(df_100plus, learning_rate_value=1e-4, output_path="MPLvsedge_heatmap_100plus.png")



diff = [0.03666871413588524 - 0.03129949793219566, 0.04019355773925781 - 0.035438649356365204,
        0.028279069811105728 - 0.027327843010425568,
        0.05038128420710564 - 0.033825941383838654, 0.05591978877782822 - 0.02615831233561039,
        0.04075648635625839 -  0.023908207193017006, 0.040882378816604614 - 0.025978272780776024,
        0.029719118028879166 - 0.02019858919084072, 0.023074351251125336 - 0.0199936181306839]

diff_mean = np.mean(diff)
diff_std = np.std(diff)
diff_max = np.max(diff)
diff_min = np.min(diff)
char_RMSE = np.mean(best_RMSE_100plus)

s = pd.Series(diff)
diff_mad = (s - s.mean()).abs().mean()

print("")
print("Spread between multiple runs (among runs which converge nicely in training): ")
print(f"Mean difference in standardized validation RMSE: {diff_mean}")
print(f"Standard dev.: {diff_std}")
print(f"Maximum spread between trials: {diff_max}")
print(f"Minimum spread: {diff_min}")
print(f"MAD: {diff_mad}")
print(f"For context, the average validation RMSE across all runs is: {char_RMSE}")